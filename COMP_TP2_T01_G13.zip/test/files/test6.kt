fun main() {
  var a: Int = readln_int();
  var b: Int = readln_int();
  var sum: Int = a + b;
  println_int(sum);
}
